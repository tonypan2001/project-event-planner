<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Event Planner</title>
    @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body>
    <div class="min-h-screen">
        <div class="w-full mx-auto h-full flex justify-center items-center" style="background: rgb(150,1,218);
        background: linear-gradient(130deg, rgba(150,1,218,1) 0%, rgba(112,0,255,1) 50%, rgba(112,0,255,1) 100%);">
            <div class="flex flex-col w-8/12 bg-white mt-16 mb-16 mx-auto shadow-2xl overflow-hidden rounded-lg">
                <div class="flex centent-center justify-between mt-10">
                    <p class="w-full text-2xl font-bold text-center"> <span class="text-mypink-dark">E</span>vent <span class="text-mypurple-dark">P</span>lanner</p>
                    <div class="w-full">
                        <h1 class="w-full text-center text-2xl font-bold">Sign Up</h1>
                        <p class="text-center text-gray-600">Fill up your information</p>
                    </div>
                    <div class="w-full"></div>
                    </div>
                    <div class="mx-10 my-4 w-auto flex justify-center flex-col items-center">
                        <!-- register box -->
                        <form method="POST" action="{{ route('register') }}"  class="m-10 w-2/3">
                            @csrf
                            <div>
                                <!-- fullname -->
                                <div> 
{{--                                  <x-input-lebel for="fullname" :value="__('Fullname')" />--}}
                                      <x-text-input id = "fullname"
                                                    class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                    type="fullname" name="fullname" 
                                                    placeholder = "fullname"
                                      />
                                </div>
                                <!-- username -->
                                <div>
{{--                                  <x-input-lebel for="username" :value="__('Username')" />--}}
                                      <x-text-input id = "username"
                                                    class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                    type="username" name="username" 
                                                    placeholder= "username"/>

                                </div>
                                <!-- email -->
                                <div>
{{--                                 <x-input-lebel for="email" :value="__('Email')" />--}}   
                                     <x-text-input  id = "email"
                                                    class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                    type="email" name="email" 
                                                    placeholder = "email"/>                              

                                </div>
                                <!-- phone number -->
                                <div>
 {{--                               <x-input-lebel for="phone_num" :value="__('Phone_num')" />--}}
                                    <x-text-input  id = "phone_num"
                                                   class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                   type="phone_num" name="phone_num" 
                                                   placeholder = "phone_num"/>

                                </div>
                                <!-- password -->
                                <div>
{{--                                <x-input-lebel for="password" :value="__('Password')" />--}}
                                    <x-text-input  id = "password"
                                                   class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                   type="password" name="password" 
                                                   required autocomplete="new-password"
                                                   placeholder = "password"/>
                                </div>
                                <!-- confirm password -->
                                <div>
 {{--                               <x-input-lebel for="password_confirmation" :value="__('Confirm Password')" />--}}
                                    <x-text-input  id = "password_confirmation"
                                                   class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                   type="password" name="password_confirmation" "
                                                   required autocomplete="new-password"
                                                   placeholder = "confirm password"/>
                                </div>
                                  <!-- age -->
                                <div>
 {{--                               <x-input-lebel for="age" :value="__('Age')" />--}}
                                    <x-text-input  id = "age"
                                                   class="border border-gray-400 py-1 px-2 rounded w-full h-12 my-2 focus:border-none focus:ring-mypink-light focus:ring-2"
                                                   type="age" name="age" 
                                                   placeholder = "age"/>
                                </div> 
                            </div>
                        </form>

                        <div class="flex content-center justify-between w-full mb-5">
                            <a href="{{route('login')}}" class="w-full">< Back</a>
                            <button class="w-full bg-mypink-light hover:bg-mypink-dark text-white font-bold py-2 px-10 rounded-full">Sign Up</button>
                            <div class="w-full"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</body>
</html>